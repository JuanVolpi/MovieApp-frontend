import axios from "axios";

const BASE_URL = import.meta.env.VITE_UTILIZADOR_API_BASE_URL;

// Buscar utilizador por username
export async function getUserByUsername(username: string) {
  const response = await axios.get(`${BASE_URL}username/${username}`);
  return response.data;
}

// Buscar utilizador por ID
export async function getUserById(id: number) {
  const response = await axios.get(`${BASE_URL}${id}`);
  return response.data;
}

// Seguir utilizador
export async function followUser(myId: number, userToFollowId: number) {
  return axios.post(`${BASE_URL}${myId}/follow`, {
    user_to_follow_id: userToFollowId,
  });
}

// Deixar de seguir utilizador
export async function unfollowUser(myId: number, userToUnfollowId: number) {
  return axios.post(`${BASE_URL}${myId}/unfollow`, {
    user_to_unfollow_id: userToUnfollowId,
  });
}

// Buscar seguidores do utilizador
export async function getFollowers(id: number) {
  const response = await axios.get(`${BASE_URL}${id}/followers`);
  return response.data; // array de utilizadores
}

// Buscar quem o utilizador segue
export async function getFollowing(id: number) {
  const response = await axios.get(`${BASE_URL}${id}/following`);
  return response.data; // array de utilizadores
}
