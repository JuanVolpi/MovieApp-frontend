import { useEffect, useState } from "react";
import FilmesPresenter from "./FilmesPresenter";
import { getFilmes, Filme } from "@/services/filmesService";

const FilmesContainer = () => {
  const [filmes, setFilmes] = useState<Filme[]>([]);
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState("");

  useEffect(() => {
    getFilmes()
      .then((res) => {
        setFilmes(res);
        setLoading(false);
      })
      .catch((err) => {
        setErro("Erro ao buscar filmes");
        setLoading(false);
      });
  }, []);

  return (
    <FilmesPresenter filmes={filmes} loading={loading} erro={erro} />
  );
};

export default FilmesContainer;
