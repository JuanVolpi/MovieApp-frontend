import type { Filme } from "@/services/filmesService";

interface Props {
  filmes: Filme[];
}

const FilmesPresenter = ({ filmes }: Props) => {
  return (
    <section className="p-6">
      <h1 className="text-2xl font-bold mb-4">Filmes em Destaque</h1>

      <div className="grid gap-4 grid-cols-2 sm:grid-cols-3 md:grid-cols-4">
        {filmes.length > 0 ? (
          filmes.map((filme) => (
            <div
              key={filme.tmdb_id}
              className="border rounded p-4 shadow hover:shadow-lg transition bg-white dark:bg-zinc-900"
            >
              <img
                src={`https://image.tmdb.org/t/p/w200${filme.poster_path}`}
                alt={filme.title}
                className="w-full h-auto mb-2 rounded"
              />
              <h2 className="text-lg font-semibold">{filme.title}</h2>
              <p className="text-sm text-gray-600">Ano: {filme.year}</p>
            </div>
          ))
        ) : (
          <p className="text-gray-500">Nenhum filme disponível.</p>
        )}
      </div>
    </section>
  );
};

export default FilmesPresenter;
