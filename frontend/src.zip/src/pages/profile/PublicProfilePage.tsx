import { useParams } from 'react-router-dom'
import { useEffect, useState } from 'react'
import {
  getUserById,
  getFollowers,
  getFollowing
} from '@/services/communityService'
import MovieGrid from '@/components/grid/MovieGrid'
import { Filme, User } from '@/types'
import { Button } from '@heroui/react'
import ListModal from '@/components/modal/ListModal'

export default function PerfilPublico () {
  const { id } = useParams<{ id: string }>()
  const [userData, setUserData] = useState<User | null>(null)
  const [filmes, setFilmes] = useState<Filme[]>([])
  const [followers, setFollowers] = useState<User[]>([])
  const [following, setFollowing] = useState<User[]>([])
  const [showModal, setShowModal] = useState<'followers' | 'following' | null>(
    null
  )

  useEffect(() => {
    if (id) {
      getUserById(Number(id)).then(setUserData)
      // Substituir por getFilmesVistosPorUsuario se tiver
      fetch(`http://localhost:5003/api/historico/${id}`)
        .then(res => res.json())
        .then(setFilmes)

      getFollowers(Number(id)).then(setFollowers)
      getFollowing(Number(id)).then(setFollowing)
    }
  }, [id])

  if (!userData)
    return <p className='text-center mt-10'>Carregando perfil...</p>

  return (
    <div className='p-6 max-w-6xl mx-auto'>
      <div className='flex flex-col sm:flex-row items-center sm:items-start gap-6 mb-8'>
        <img
          src={userData.avatar || `https://i.pravatar.cc/150?u=${userData.id}`}
          className='w-32 h-32 rounded-full border-4 border-white shadow-md'
          alt='avatar'
        />
        <div className='text-center sm:text-left'>
          <h1 className='text-3xl font-bold'>{userData.username}</h1>
          <p className='text-default-500'>{userData.email}</p>
          <div className='mt-3 flex justify-center sm:justify-start gap-4'>
            <Button size='sm' onClick={() => setShowModal('followers')}>
              Seguidores ({followers.length})
            </Button>
            <Button size='sm' onClick={() => setShowModal('following')}>
              Seguindo ({following.length})
            </Button>
          </div>
        </div>
      </div>

      <h2 className='text-2xl font-semibold mb-4'>Últimos assistidos</h2>
      <MovieGrid
        filmes={filmes}
        onFilmeClick={function (filme: Filme): void {
          throw new Error('Function not implemented.')
        }}
      />

      <ListModal
        title={showModal === 'followers' ? 'Seguidores' : 'Seguindo'}
        isOpen={!!showModal}
        onClose={() => setShowModal(null)}
        users={showModal === 'followers' ? followers : following}
      />
    </div>
  )
}
