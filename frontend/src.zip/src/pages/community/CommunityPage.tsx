import { useEffect, useState } from 'react'
import UserCard from '@/components/card/UserCard'
import SearchBox from '@/components/input/SearchBox'
import Navbar from '@/components/navbar'
import {
  getUserByUsername,
  followUser,
  unfollowUser
} from '@/services/communityService'
import { useAuth } from '@/context/AuthContext'

interface Utilizador {
  id: number
  username: string
  jaSegue: boolean
}

export default function CommunityPage () {
  const [query, setQuery] = useState('')
  const [utilizadores, setUtilizadores] = useState<Utilizador[]>([])
  const { user } = useAuth()
  console.log('User logado:', user)
  const fetchUtilizador = async (texto: string) => {
    try {
      const result = await getUserByUsername(texto)
      if (result && user && result.followers) {
        const jaSegue = result.followers.some((f: any) => f.id === user.id)
        setUtilizadores([{ id: result.id, username: result.username, jaSegue }])
      } else {
        setUtilizadores([])
      }
    } catch (err) {
      console.error('Erro ao buscar utilizadores:', err)
      setUtilizadores([])
    }
  }

  const handleFollowToggle = async (id: number, jaSegue: boolean) => {
    if (!user) return
    try {
      if (jaSegue) {
        await unfollowUser(user.id, id)
      } else {
        await followUser(user.id, id)
      }
      setUtilizadores(prev =>
        prev.map(u => (u.id === id ? { ...u, jaSegue: !jaSegue } : u))
      )
    } catch (err) {
      console.error('Erro ao alternar follow:', err)
    }
  }

  useEffect(() => {
    if (query.trim() !== '') fetchUtilizador(query)
    else setUtilizadores([])
  }, [query])

  return (
    <>
      <Navbar />
      <div className='max-w-3xl mx-auto p-4 space-y-6'>
        <h1 className='text-2xl font-bold'>Comunidade</h1>

        <SearchBox
          value={query}
          onChange={setQuery}
          onClear={() => setQuery('')}
          placeholder='Pesquisar por nome ou ID...'
        />

        <div className='space-y-4'>
          {utilizadores.map(user => (
            <UserCard
              key={user.id}
              id={user.id}
              nome={user.username}
              jaSegue={user.jaSegue}
              onFollowToggle={() => handleFollowToggle(user.id, user.jaSegue)}
            />
          ))}
        </div>
      </div>
    </>
  )
}
